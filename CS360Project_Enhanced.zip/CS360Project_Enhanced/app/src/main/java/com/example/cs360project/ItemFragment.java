package com.example.cs360project;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

//Container for items
public class ItemFragment extends Fragment {

    //Constructor
    public ItemFragment() {
        super(R.layout.item_layout);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Add item fragment to container view
        if (savedInstanceState == null) {
            getParentFragmentManager().beginTransaction()
                    .setReorderingAllowed(true)
                    .add(R.id.fragment_container_view, ItemFragment.class, null)
                    .commit();
        }
    }
}
