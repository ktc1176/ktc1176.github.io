package com.example.cs360project;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;

import org.json.JSONObject;

//MongoDB connection class
public class MongoDBConnection {
    //Database connection string
    private static final String CONNECTION_STRING = "localhost:27017";

    //retrieves mongo client with proper connection string
    public static MongoClient getMongoClient() {
        return MongoClients.create(CONNECTION_STRING);
    }
}
