package com.example.cs360project;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import org.bson.Document;

//Database handler class
public class DatabaseHandler {

    //function for inserting item into database
    public static void insertItem()
    {
        //gets mongoDB client and correct database and collection
        MongoClient mongoClient = MongoDBConnection.getMongoClient();
        MongoDatabase database = mongoClient.getDatabase("inventory");
        MongoCollection<Document> collection = database.getCollection("items");

        //Creates new example document
        Document doc = new Document("text","label").append("src","@drawable/baseline_cookie_24");

        //inserts data into collection
        collection.insertOne(doc);

        //closes database
        mongoClient.close();
    }

}
